<html>
	<head>
		<title>Reporting Package</title>
	</head>
	<body>
	<h2> Upload your CSV File</h2>
		<form name="name1" method="post" action="" enctype="multipart/form-data">
			<input type="file" name="uploadfiles" id="uploadfiles" class="required" accept=".csv,text/csv"><br />
			<input type="submit" name="submit" value="uploadSubmit"><br />
		</form>
	</body>
</html>

<?php
error_reporting(0);
ini_set('display_errors',1);
ini_set('default_socket_timeout', 1);
require_once('./nusoap/nusoap.php');

	// This is your Web service server WSDL URL address
	$wsdl = "http://gatsint.pjm-eis.com:8088/thirdpartyreporter/thirdpartyreporter.wsdl";
	// Create client object
	$client = new nusoap_client($wsdl,true);

	$err = $client->getError();

		if ($err) {
		   // Display the error
		   echo '<h2>Constructor error</h2>' . $err;
		   // At this point, you know the call that follows will fail
		   exit();
		}
	// Input parameter for WSDL

	
$generationUpload= array(array('RowID'=>2,'AccountID'=>16645,'GeneratorID'=>84487,'GenerationLevel'=>"K",'PreviousMeterReading'=>438303,'CurrentMeterReading'=>448303,
    'CurrentMeterReadingDate'=>"2020-08-31",'NetGeneration'=>10000,'MonthYearGeneration'=>82020));


	$meterData= array(0 => array('MeterID'=>1,'PreviousMeterReading'=>438303,'CurrentMeterReading'=>448303,'NetGeneration'=>10000));

	$param=array('tprName'=>"SLWEB",'tprToken'=>"0EEDB49B-EC87-498A-9D57-C80FD6AB3848",'generationRecords'=>array('GenerationUpload'=>$generationUpload,'Meters'=>array('MeterData'=>$meterData)));

	$result = $client->call('RequestLoadGen', array('parameters' => $param), '', '', false, true);
		if ($client->fault) {
				echo 'Error: ';
				print_r($result);
		} 
		else {
				// check result
				$err_msg = $client->getError();
				if ($err_msg) {
				// Print error msg
				echo 'Error: '.$err_msg;
				} 
				else {
				// Print result
				echo 'Result: ';
				print_r($result);
			}
		}

	echo '<h2>Request</h2><pre>' . htmlspecialchars($client->request, ENT_QUOTES) . '</pre>';
	echo '<h2>Response</h2><pre>' . htmlspecialchars($client->response, ENT_QUOTES) . '</pre>';
	echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->debug_str, ENT_QUOTES) 
	// print_r($result); // If success then print response coming from SOAP Server

 ?>

