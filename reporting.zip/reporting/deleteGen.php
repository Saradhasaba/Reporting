<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script language="javascript" type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap" rel="stylesheet"> 
<script>
jQuery(function() {
	jQuery(".btn-block .btn-sec").on('click',function() {
		jQuery(".response-success").html('');
	});
});


 function export1(tableID, filename = ''){
    var downloadLink;
   var dataType = 'application/vnd.ms-excel';
   var tableSelect = document.getElementById(tableID);
   var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
   
   // Specify file name
   filename = filename?filename+'.xls':'excel_data.xls';
   
   // Create download link element
   downloadLink = document.createElement("a");
   
   document.body.appendChild(downloadLink);
   
   if(navigator.msSaveOrOpenBlob){
       var blob = new Blob(['\ufeff', tableHTML], {
           type: dataType
       });
       navigator.msSaveOrOpenBlob( blob, filename);
   }else{
       // Create a link to the file
       downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
   
       // Setting the file name
       downloadLink.download = filename;
       
       //triggering the function
       downloadLink.click();
   }
}
</script>
<!--<style>
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;700&display=swap');
</style> -->
<style>
body {
  font-family: Roboto, Helvetica, sans-serif;
  background-color: black;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
}
.container .form-block {
  background-color: white;
  width:1000px;
  padding:50px;
  display:block;
  margin:0 auto;
  }

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}
h1 {font-size:26px;line-height:36px;text-align:center;}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #015c89;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}
.exportbtn {
  background-color: #015c89;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  opacity: 0.9;
  margin-left:500px;
}

.exportbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
.form-cont {text-align:center;}
.btn-block {text-align:center;padding:30px 0;}
.btn-block input {width:200px;margin-left:20px;text-transform:uppercase;font-weight:bold;}
.btn-block input:first-child {margin-left:0px;}
.btn-block .btn-sec {background:#ccc;color:#000;}
.response-success table {width:100%;padding:0px;margin:0px}
.response-success table th {color:#fff; background:#333;padding:10px 15px;font-size:13px;}
.response-success table td {text-align:center;padding:10px 15px;font-size:13px;}
.response-success table tr:nth-child(2n+1) {background:#f1f1f1}
.response-success table tr:nth-child(2n+2) {background:#f9f9f9}
</style>
</head>
<body>

  <div class="container">
	<div class="form-block">
<form name="name1" method="post" action="" enctype="multipart/form-data">
		<h1>Deleting Generation Data</h1>
		<hr>
		<div class="form-cont">
			<label for="email"><b>Please Upload the Csv file for deletion</b></label>
			<input type="file" name="uploadfiles"  id="uploadfiles" accept=".csv,text/csv" class="required">
		</div>
		<div class="btn-block">
			<input type="submit" name="submit"  class="registerbtn" value="UPLOAD">
			<input type="button" name="cleardata"  class="registerbtn btn-sec" value="Clear Data">


<?php
error_reporting(0);
ini_set('display_errors',1);
ini_set('default_socket_timeout', 1);
require_once('./nusoap/nusoap.php');

// This is your Web service server WSDL URL address

	$wsdl = "http://gatsint.pjm-eis.com:8088/thirdpartyreporter/thirdpartyreporter.wsdl";
	
	// Create client object
	$client = new nusoap_client($wsdl,true);

	$err = $client->getError();

		if ($err) {
		   // Display the error
		   echo '<h2>Constructor error</h2>' . $err;
		   // At this point, you know the call that follows will fail
		   exit();
		}

// Reading the csv file
$param = array();
$f = fopen($_FILES['uploadfiles']['tmp_name'], 'r');
while(!feof($f)) {

    $row = fgetcsv($f);
	

    if (!empty($row)) {
		
	// Input parameter for WSDL	 
	$deleteGenerationUpload= array('AccountID'=>$row[2],'GeneratorID'=>$row[3]);

	$param[]=array('tprName'=>$row[0],'tprToken'=>$row[1],'GeneratorDeletions'=>array('DeleteGenerationUpload'=>$deleteGenerationUpload));
	  
    }
}
fclose($f);
?>
</form>
<input type="button" name="Export" OnClick="export1('datatable','data')" class="exportbtn"  value="Export"/>
<div class="response-success">
		<table id="datatable">
			<tr>
				<th> Account ID</th>
				<th> Generation ID</th>
				<th> Response Code</th>
			</tr>
<?php 			
$total = count($param);
for($i=1;$i<$total;$i++){
//print_r($param[$i]);
$result = $client->call('DeleteGeneration', array('parameters' => $param[$i]), '', '', false, true);


		if ($client->fault) {
				echo 'Error: ';
				print_r($result);
		} 
		else {
				// check result
				$err_msg = $client->getError();
				if ($err_msg) {
				// Print error msg
				echo 'Error: '.$err_msg;
				} 
				else {
					
				?><tr>

					<td><?php print_r($result['DeleteGenerationResult']['DeleteGenerationReturn']['AccountID']);?></td>
					<td><?php print_r($result['DeleteGenerationResult']['DeleteGenerationReturn']['GeneratorID']);?></td>
					<td><?php print_r($result['DeleteGenerationResult']['DeleteGenerationReturn']['Code']);?></td>
				<tr>
				<?php	
				}
			}
		}	

 ?>
</table>
		</div>
	
 </div>
  </div>
<script>

</script>
</body>
</html>	

